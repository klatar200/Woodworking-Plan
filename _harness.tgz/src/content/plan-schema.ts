import { z } from 'zod';

/**
 * The contract every seed file in content/plans/*.json must satisfy.
 *
 * Why this is strict: BUSINESS_PLAN.md §12 names "thin/low-quality catalog" and
 * inconsistent metadata as the top risks to trust, and §6 requires editorial QC
 * so "search and filters remain trustworthy." A plan with a missing tool list or
 * a cost tier that contradicts its dollar range silently poisons every filter we
 * build in Sprints 4–5. Catching that here — at ingestion, in CI — is the whole
 * point of the content pipeline.
 *
 * `.strict()` everywhere is deliberate: a typo'd key ("dificulty") should fail
 * loudly, not be silently dropped.
 */

const slug = z
  .string()
  .min(1)
  .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, 'must be a lowercase kebab-case slug');

/** Money is integer cents everywhere. Never floats. */
const cents = z.number().int().nonnegative();

export const COST_TIERS = ['TIER_1', 'TIER_2', 'TIER_3', 'TIER_4', 'TIER_5'] as const;
export type CostTierName = (typeof COST_TIERS)[number];

/**
 * The $ – $$$$$ scale, anchored to real dollar ranges so the tier a plan claims
 * can be checked against the cost it actually has. Without this, "cost tier" is
 * just a vibe and the cheap/expensive filter lies to people.
 *
 * Bounds are on the plan's MAXIMUM estimated material cost, in cents.
 */
export const COST_TIER_BOUNDS: Record<CostTierName, { maxUpToCents: number }> = {
  TIER_1: { maxUpToCents: 5_000 }, // $      up to $50
  TIER_2: { maxUpToCents: 15_000 }, // $$     $50–$150
  TIER_3: { maxUpToCents: 35_000 }, // $$$    $150–$350
  TIER_4: { maxUpToCents: 75_000 }, // $$$$   $350–$750
  TIER_5: { maxUpToCents: Number.MAX_SAFE_INTEGER }, // $$$$$  $750+
};

const toolRef = z
  .object({
    slug,
    essential: z.boolean().default(true),
    note: z.string().min(1).optional(),
  })
  .strict();

const material = z
  .object({
    name: z.string().min(1),
    unit: z.string().min(1),
    quantity: z.number().positive(),
    species: z.string().min(1).optional(),
    costCents: cents.optional(),
    note: z.string().min(1).optional(),
  })
  .strict();

const cutListItem = z
  .object({
    part: z.string().min(1),
    quantity: z.number().int().positive(),
    thicknessIn: z.number().positive(),
    widthIn: z.number().positive(),
    lengthIn: z.number().positive(),
    material: z.string().min(1).optional(),
    note: z.string().min(1).optional(),
  })
  .strict();

const step = z
  .object({
    title: z.string().min(1),
    body: z.string().min(1),
    /**
     * Sprint 21 — which of the PLAN'S tools/materials this step uses.
     *
     * Both OPTIONAL and default to empty: a step (and a whole plan) that predates the
     * content pass still validates, and the feature simply renders nothing for it. That
     * is what lets the 24-plan tagging happen incrementally instead of as a big-bang
     * edit that breaks every plan the moment the schema lands.
     *
     * `tools` are TOOL SLUGS; `materials` are MATERIAL NAMES (materials have no slug —
     * they are plan-local line items keyed by name). Both must be a SUBSET of what the
     * plan itself declares — enforced in load.ts, which can name the offending file and
     * step. Zod can't see the sibling `tools`/`materials` arrays from inside a step, so
     * the subset check lives one level up.
     */
    tools: z.array(slug).default([]),
    materials: z.array(z.string().min(1)).default([]),
    /**
     * Optional per-step photo/diagram: a URL that MUST be one of the plan's own
     * `images[]`. The subset is enforced in load.ts (like `tools`/`materials`)
     * because Zod can't see the sibling `images` array from inside a step.
     * Optional and unset by default, so every existing plan validates unchanged
     * and a step simply renders no image until one is assigned to it.
     */
    image: z.string().url().optional(),
  })
  .strict();

const image = z
  .object({
    url: z.string().url(),
    // Not optional. An empty alt on a catalog image is an accessibility bug we
    // would only have to fix later (Sprint 9).
    alt: z.string().min(1),
    isPrimary: z.boolean().default(false),
  })
  .strict();

export const planSchema = z
  .object({
    slug,
    title: z.string().min(1),
    summary: z.string().min(1).max(200),
    description: z.string().min(1),

    category: slug,

    difficulty: z.number().int().min(1).max(5),

    timeMinMinutes: z.number().int().positive(),
    timeMaxMinutes: z.number().int().positive(),
    timeLabel: z.string().min(1),

    costTier: z.enum(COST_TIERS),
    costMinCents: cents,
    costMaxCents: cents,

    tags: z.array(z.string().min(1)).min(1),

    tools: z.array(toolRef).min(1),
    materials: z.array(material).min(1),
    cutList: z.array(cutListItem),
    steps: z.array(step).min(1),
    images: z.array(image),

    /**
     * Content-ops 2026-07-17: images whose ORIGINAL source URL 404'd during the
     * R2 migration. Moved here rather than deleted so the source URL is PRESERVED
     * for later recovery (Keagan owns the source site and can look up the correct
     * image), while `images` is emptied so the plan renders the honest placeholder
     * instead of a broken image. OPTIONAL, and IGNORED by the seed — it never
     * reaches the database; this is purely a source-file annotation. Populated by
     * scripts/null-unresolved-images.mjs.
     */
    unresolvedImages: z.array(image).optional(),

    published: z.boolean().default(true),
  })
  .strict()
  // --- Cross-field integrity. These are the checks that keep filters honest. ---
  .refine((p) => p.timeMaxMinutes >= p.timeMinMinutes, {
    message: 'timeMaxMinutes must be >= timeMinMinutes',
    path: ['timeMaxMinutes'],
  })
  .refine((p) => p.costMaxCents >= p.costMinCents, {
    message: 'costMaxCents must be >= costMinCents',
    path: ['costMaxCents'],
  })
  .refine((p) => p.costMaxCents <= COST_TIER_BOUNDS[p.costTier].maxUpToCents, {
    message:
      'costTier contradicts costMaxCents — the plan claims a cheaper tier than it actually costs. See COST_TIER_BOUNDS.',
    path: ['costTier'],
  })
  .refine((p) => p.tools.some((t) => t.essential), {
    message: 'a plan must require at least one essential tool',
    path: ['tools'],
  })
  .refine((p) => p.images.filter((i) => i.isPrimary).length <= 1, {
    message: 'at most one image may be marked isPrimary',
    path: ['images'],
  });

export type PlanInput = z.infer<typeof planSchema>;

export const categorySchema = z
  .object({
    slug,
    name: z.string().min(1),
    description: z.string().min(1).optional(),
    sortOrder: z.number().int().default(0),
  })
  .strict();

export type CategoryInput = z.infer<typeof categorySchema>;

export const toolSchema = z
  .object({
    slug,
    name: z.string().min(1),
    category: z.string().min(1).optional(),
  })
  .strict();

export type ToolInput = z.infer<typeof toolSchema>;

/**
 * A skill-building learning path — Sprint 16.
 *
 * `.strict()` like every other schema here: an unexpected key is a typo, and a typo in
 * content that silently validates is content that silently does the wrong thing.
 */
export const pathSchema = z
  .object({
    slug,
    title: z.string().min(1),
    summary: z.string().min(1),
    description: z.string().min(1),
    sortOrder: z.number().int().default(0),
    published: z.boolean().default(true),

    /**
     * QOL-E — the level of woodworker this path is FOR, on the SAME 1–5 scale as
     * `Plan.difficulty` (DECISIONS_LOG.md 2026-07-19). One vocabulary for the site.
     *
     * REQUIRED, with no default. It is a judgement about the reader, not a fact
     * derivable from the steps — "Joinery: From Screws to Dovetails" opens with a
     * difficulty-2 bookcase and is emphatically not a beginner's path — so it has to be
     * authored, and a default would let a path ship silently claiming to be for
     * beginners. Same argument as `reason` below: make it non-negotiable in the schema
     * rather than a habit someone might drop.
     */
    experienceLevel: z.number().int().min(1).max(5),

    /**
     * QOL-E — the category slug this path is about, or `null` for one that deliberately
     * spans several. Checked against the real categories in load.ts, like a plan's.
     *
     * NULLABLE BUT NOT OPTIONAL: the key must be present, so "this path spans
     * categories" is something an author states rather than something they forgot.
     */
    category: slug.nullable(),

    steps: z
      .array(
        z
          .object({
            /** Plan slug. Checked against the real catalog in load.ts. */
            plan: slug,
            /**
             * REQUIRED. Not optional, and `.min(1)` so an empty string cannot slip past.
             *
             * An ordered list of plans with no explanation of why each one comes where
             * it does is not a learning path — it is a collection with a number next to
             * each item. The reason IS the teaching, and the schema is where we make
             * that non-negotiable rather than a habit someone might drop.
             */
            reason: z.string().min(1),
          })
          .strict(),
      )
      // A "path" of one plan is a plan. Two is the minimum that teaches a sequence.
      .min(2),
  })
  .strict();

export type PathInput = z.infer<typeof pathSchema>;

/** Human-readable `$`–`$$$$$` for display. */
export function costTierSymbol(tier: CostTierName): string {
  return '$'.repeat(COST_TIERS.indexOf(tier) + 1);
}
